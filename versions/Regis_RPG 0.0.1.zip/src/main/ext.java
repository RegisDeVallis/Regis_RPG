package main;


public class ext {
	
	public static void exit() throws Exception {
           
                
            System.out.println("Exiting the program");
            System.out.println("Exited!");
		 
	    System.exit(0);
            
		
            
	}

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.Scanner;

/**
 *
 * @author Dalen
 */
public class askyn {
    
    public static void askYesNo() throws InterruptedException {
        
        String yesNoNum;
       
        System.out.println("1: Yes");
        System.out.println("2: No");
        
        scn.scan();
        
        if (glblVar.answer .equals ("1")) {
        
            glblVar.yesno = true;
    }
        else {
            glblVar.yesno = false;
        }
    }
    
    
    
    
    
}

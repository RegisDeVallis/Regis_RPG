package main;


public class qst {
	
	public static void quests() throws Exception {
            
            System.out.println("WIP");
            mnu.Menu();
		
	}
}

package main;


public class bg {
	
	public static void bag() {
		
	}
}

package main;




public class atk {
	
	public static void attack() throws Exception {
		System.out.println("WIP");
                mnu.Menu();
	}

}

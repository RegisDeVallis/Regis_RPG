Regis RPG
=========

Text based RPG in Java. Not much else to explain. Unstable at the moment, expect new updates. Curently you need to download and run
in Netbeans to play. Gui is in the making.
